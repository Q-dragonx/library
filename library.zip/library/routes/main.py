from flask import render_template, url_for, flash, redirect, request, Blueprint
from extensions import db
from models import User, Book, BorrowRecord
from flask_login import login_required, current_user
from datetime import datetime, timedelta

# 创建蓝图
main = Blueprint('main', __name__)

# 主页
@main.route('/')
def home():
    return render_template('home.html')

# 图书入库（仅管理员）
@main.route('/books/add', methods=['GET', 'POST'])
@login_required
def add_book():
    if not current_user.is_admin:
        flash('Access denied. Only administrators can add books', 'danger')
        return redirect(url_for('main.home'))
    
    if request.method == 'POST':
        isbn = request.form.get('isbn')
        title = request.form.get('title')
        author = request.form.get('author')
        publisher = request.form.get('publisher')
        location = request.form.get('location')
        stock = request.form.get('stock')
        
        # 检查ISBN是否已存在
        book_exists = Book.query.filter_by(isbn=isbn).first()
        if book_exists:
            flash('Book with this ISBN already exists', 'danger')
            return redirect(url_for('main.add_book'))
        
        # 创建新图书
        book = Book(isbn=isbn, title=title, author=author, publisher=publisher, location=location, stock=int(stock))
        db.session.add(book)
        db.session.commit()
        
        flash('Book added successfully!', 'success')
        return redirect(url_for('main.books'))
    
    return render_template('add_book.html')

# 图书列表（支持查询和分页）
@main.route('/books')
def books():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    # 处理查询参数
    search = request.args.get('search', '')
    filter_by = request.args.get('filter_by', 'title')
    
    # 构建查询
    if search:
        if filter_by == 'title':
            books = Book.query.filter(Book.title.ilike(f'%{search}%')).paginate(page=page, per_page=per_page)
        elif filter_by == 'author':
            books = Book.query.filter(Book.author.ilike(f'%{search}%')).paginate(page=page, per_page=per_page)
        elif filter_by == 'isbn':
            books = Book.query.filter(Book.isbn.ilike(f'%{search}%')).paginate(page=page, per_page=per_page)
        elif filter_by == 'publisher':
            books = Book.query.filter(Book.publisher.ilike(f'%{search}%')).paginate(page=page, per_page=per_page)
        else:
            books = Book.query.paginate(page=page, per_page=per_page)
    else:
        books = Book.query.paginate(page=page, per_page=per_page)
    
    return render_template('books.html', books=books, search=search, filter_by=filter_by)

# 借书功能
@main.route('/books/<int:book_id>/borrow')
@login_required
def borrow_book(book_id):
    book = Book.query.get_or_404(book_id)
    
    # 检查库存
    if book.stock <= 0:
        flash('Book is out of stock', 'danger')
        return redirect(url_for('main.books'))
    
    # 检查用户是否已有未归还的该书
    existing_borrow = BorrowRecord.query.filter_by(user_id=current_user.id, book_id=book_id, status='借阅中').first()
    if existing_borrow:
        flash('You already have this book checked out', 'danger')
        return redirect(url_for('main.books'))
    
    # 创建借阅记录
    borrow_date = datetime.utcnow()
    due_date = borrow_date + timedelta(days=30)  # 默认借阅30天
    
    borrow_record = BorrowRecord(
        user_id=current_user.id,
        book_id=book_id,
        borrow_date=borrow_date,
        due_date=due_date,
        status='借阅中'
    )
    
    # 更新库存
    book.stock -= 1
    
    db.session.add(borrow_record)
    db.session.commit()
    
    flash(f'You have successfully borrowed "{book.title}"', 'success')
    return redirect(url_for('main.books'))

# 还书功能
@main.route('/books/<int:book_id>/return')
@login_required
def return_book(book_id):
    # 查找未归还的借阅记录
    borrow_record = BorrowRecord.query.filter_by(user_id=current_user.id, book_id=book_id, status='借阅中').first()
    
    if not borrow_record:
        flash('No active borrow record found for this book', 'danger')
        return redirect(url_for('main.books'))
    
    # 更新借阅记录
    borrow_record.return_date = datetime.utcnow()
    borrow_record.status = '已归还'
    
    # 更新图书库存
    book = Book.query.get_or_404(book_id)
    book.stock += 1
    
    # 检查是否逾期
    if borrow_record.return_date > borrow_record.due_date:
        days_overdue = (borrow_record.return_date - borrow_record.due_date).days
        flash(f'Book returned successfully, but you were {days_overdue} days overdue', 'warning')
    else:
        flash(f'Book "{book.title}" returned successfully', 'success')
    
    db.session.commit()
    return redirect(url_for('main.my_borrows'))

# 我的借阅记录
@main.route('/my_borrows')
@login_required
def my_borrows():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    borrows = BorrowRecord.query.filter_by(user_id=current_user.id).order_by(BorrowRecord.borrow_date.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('my_borrows.html', borrows=borrows)

# 统计报表 - 借阅排行榜
@main.route('/reports/borrow_rankings')
@login_required
def borrow_rankings():
    if not current_user.is_admin:
        flash('Access denied. Only administrators can view reports', 'danger')
        return redirect(url_for('main.home'))
    
    # 获取借阅排行榜
    from sqlalchemy import func
    
    # 按图书分组统计借阅次数
    book_rankings = db.session.query(
        Book.title,
        func.count(BorrowRecord.id).label('borrow_count')
    ).join(BorrowRecord, Book.id == BorrowRecord.book_id)
    
    # 按用户分组统计借阅次数
    user_rankings = db.session.query(
        User.username,
        func.count(BorrowRecord.id).label('borrow_count')
    ).join(BorrowRecord, User.id == BorrowRecord.user_id)
    
    # 按月统计
    month = request.args.get('month')
    year = request.args.get('year')
    
    if month and year:
        start_date = datetime(int(year), int(month), 1)
        if int(month) == 12:
            end_date = datetime(int(year) + 1, 1, 1)
        else:
            end_date = datetime(int(year), int(month) + 1, 1)
        
        book_rankings = book_rankings.filter(BorrowRecord.borrow_date >= start_date, BorrowRecord.borrow_date < end_date)
        user_rankings = user_rankings.filter(BorrowRecord.borrow_date >= start_date, BorrowRecord.borrow_date < end_date)
    
    # 按季度统计
    quarter = request.args.get('quarter')
    year = request.args.get('year')
    
    if quarter and year:
        quarter = int(quarter)
        start_month = (quarter - 1) * 3 + 1
        end_month = quarter * 3 + 1
        start_date = datetime(int(year), start_month, 1)
        if end_month > 12:
            end_date = datetime(int(year) + 1, 1, 1)
        else:
            end_date = datetime(int(year), end_month, 1)
        
        book_rankings = book_rankings.filter(BorrowRecord.borrow_date >= start_date, BorrowRecord.borrow_date < end_date)
        user_rankings = user_rankings.filter(BorrowRecord.borrow_date >= start_date, BorrowRecord.borrow_date < end_date)
    
    # 执行查询并排序
    book_rankings = book_rankings.group_by(Book.id).order_by(func.count(BorrowRecord.id).desc()).limit(10).all()
    user_rankings = user_rankings.group_by(User.id).order_by(func.count(BorrowRecord.id).desc()).limit(10).all()
    
    return render_template('borrow_rankings.html', book_rankings=book_rankings, user_rankings=user_rankings)